using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class HeroStatusUI : MonoBehaviour
{
    public UISlider middleSlider;
    public UISlider slider;
    //public Transform arrowRotate;
    //public Transform arrowPos;

    private Tween hpTween;

    private void Start()
    {
        //arrowPos.DOKill();
        //arrowPos.localPosition = Vector3.one;
        //arrowPos.DOScale(Vector3.one * 1.15f, 0.8f).SetLoops(-1, LoopType.Yoyo);
    }

    public void SetSliderValue(float _value, bool _tween = false)
    {
        float lastValue = this.slider.value;

        this.slider.value = _value;
        if(hpTween != null)
        {
            hpTween.Kill();
        }

        if (_tween)
        {
            hpTween = DOTween.To(() => lastValue, x =>
            {
                middleSlider.value = x;
            }, _value, 0.5f);
        }
        else
        {
            this.middleSlider.value = _value;
        }
    }

    private void OnDestroy()
    {
        if (hpTween != null)
        {
            hpTween.Kill();
        }
    }
}
