using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FrankGame.Battle
{
    public abstract class TargetMsgBase : MsgBase
    {
        public int targetId;

        protected TargetMsgBase(int _targetId, int _senderId, int _frame, int _sort) : base(_senderId, _frame, _sort)
        {
            this.targetId = _targetId;
        }
    }
}
