﻿using UnityEngine;

namespace FrankGame.Battle
{
    public class EffectEntity : Entity
    {
        public override EEntityType EntityType => EEntityType.Effect;
        public override bool RequiresLateUpdate => false;

        public EffectComponent effectCom;
        public AssetComponent assetCom;

        private Vector2 effectPos;
        
        public EffectEntity(EntityAdmin _admin) : base(_admin)
        {
        }

        
        protected override void OnCreate()
        {
            this.effectCom = AddComponent<EffectComponent>(ECompType.Effect);
            this.assetCom = AddComponent<AssetComponent>(ECompType.Asset);
        }

        protected override void OnUpdate(float _deltaTime, float _unscaledDeltaTime)
        {
            this.effectCom.Update(_deltaTime);
            if (this.effectCom.IsNeedDestory())
            {
                this.world.RemoveEntity(this.ID);
                return;
            }

            if (this.effectCom.MountTargetEid > 0 && !SyncMountTargetPosition())
                this.world.RemoveEntity(this.ID);
        }

        protected override void OnLateUpdate(float _deltaTime, float _unscaledDeltaTime)
        {
            
        }

        public void SetDestoryCallback(System.Action<int> _onDestoryCallback)
        {
            this.effectCom.SetDestoryCallback(_onDestoryCallback);
        }

        public void SetPos(Vector2 _pos)
        {
            effectPos = _pos;
        }

        /// <summary>
        /// 设置持续特效的逻辑挂载目标。资源不成为目标 GameObject 的子节点，由 EffectEntity 每帧同步位置。
        /// </summary>
        public void SetMountTarget(int targetEid)
        {
            effectCom.SetMountTarget(targetEid);
            SyncMountTargetPosition();
        }

        /// <summary>同步环形世界中的目标表现位置；目标失效时返回 false，交由 EffectSystem 回收本特效。</summary>
        private bool SyncMountTargetPosition()
        {
            if (!world.TryGetEntity(effectCom.MountTargetEid, out Entity target)
                || target.IsDirty()
                || !target.TryGetComponent(ECompType.Transform, out TransformComponent targetTransform))
            {
                return false;
            }

            effectPos = targetTransform.position;
            SetPos(effectPos);
            return true;
        }

        protected override void OnDestroy()
        {
            
        }

        public override void OnRecover()
        {
            effectPos = Vector2.zero;
            effectCom = null;
            assetCom = null;
        }
    }
}
